import { PricingCard } from './components/PricingCard';
import styles from './PricingCard.module.css';

const pricingPlans = [
  {
    plan: 'Basic',
    storage: '100GB',
    price: '$1.99/Month',
    features: ['100 GB of storage', 'Option to add members', 'Extra member benefits'],
    isHighlighted: false,
  },
  {
    plan: 'Standard',
    storage: '200GB',
    price: '$3.99/Month',
    features: ['200 GB of storage', 'Option to add members', 'Extra member benefits'],
    isHighlighted: true,
  },
  {
    plan: 'Premium',
    storage: '2 TB',
    price: '$8.99/Month',
    features: ['2 TB of storage', 'Option to add members', 'Extra member benefits'],
    isHighlighted: false,
  },
];

export const PricingCards = () => {
  return (
    // Global Container
    <div className={styles.globalContainer}>
      {/* Inner Container */}
      <div className={styles.innerContainer}>
        {pricingPlans.map((plan, index) => (
          <PricingCard
            key={index}
            plan={plan.plan}
            storage={plan.storage}
            price={plan.price}
            features={plan.features}
            isHighlighted={plan.isHighlighted}
          />
        ))}
      </div>
    </div>
  );
}