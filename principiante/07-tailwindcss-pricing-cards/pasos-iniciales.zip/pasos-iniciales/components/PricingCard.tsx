import styles from '../PricingCard.module.css';

interface Props {
  plan: string;
  storage: string;
  price: string;
  features: string[];
  isHighlighted?: boolean;
}

export const PricingCard = ({
  plan,
  storage,
  price,
  features,
  isHighlighted = false,
}: Props) => {
  // Clases condicionales usando template literals
  const cardClasses = `${styles.card} ${isHighlighted ? styles.highlighted : ''}`;
  const buttonClasses = `${styles.purchaseButton} ${isHighlighted ? styles.highlighted : ''}`;

  return (
    <div className={cardClasses}>
      {/* Upper Container */}
      <div className={styles.upperContainer}>
        <div className={styles.planTitle}>{plan}</div>
        <h2 className={styles.storageTitle}>{storage}</h2>
        <h3 className={styles.price}>{price}</h3>
        <div className={styles.buttonContainer}>
          <a href="#" className={buttonClasses}>
            Purchase
          </a>
        </div>
      </div>

      {/* Border */}
      <div className={styles.border}></div>

      {/* Lower Container */}
      <div className={styles.lowerContainer}>
        {/* List Container */}
        <div className={styles.featuresList}>
          {features.map((feature, index) => (
            <div key={index} className={styles.featureItem}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                strokeWidth="2"
                stroke="currentColor"
                fill="none"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                <path d="M5 12l5 5l10 -10" />
              </svg>
              <span>{feature}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};