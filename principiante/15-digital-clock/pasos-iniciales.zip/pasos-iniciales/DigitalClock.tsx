import { useState, useEffect } from 'react';
import { CustomJumbotron } from '../shared/custom/CustomJumbotron';

// Interfaz para la fecha y hora formateada.
interface FormattedDateTime {
  date: string;
  hours: string;
  minutes: string;
  seconds: string;
}

// Función de ayuda para formatear el objeto Date.
const formatDateTime = (date: Date): FormattedDateTime => {
  return {
    date: date.toLocaleDateString('es', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }),
    hours: String(date.getHours()).padStart(2, '0'),
    minutes: String(date.getMinutes()).padStart(2, '0'),
    seconds: String(date.getSeconds()).padStart(2, '0'),
  }
}

export const DigitalClock = () => {

  // TODO: Crea un estado `currentDateTime` para guardar la fecha y hora.

  // TODO: Usa un `useEffect` para actualizar la hora cada segundo.
  // 1. Dentro del `useEffect`, crea un intervalo (`setInterval`) que se ejecute cada 1000ms.
  // 2. En cada intervalo, actualiza el estado `currentDateTime` con la nueva hora.
  // 3. ¡Importante! No olvides limpiar el intervalo cuando el componente se desmonte.


  return (
    <div className="flex flex-col gap-10 min-h-screen items-center justify-center">
      <CustomJumbotron title='Digital Clock' />

      <div className="text-center">
        <div className="rounded-lg bg-black/50 p-8 text-white shadow-2xl backdrop-blur-sm">
          <div className="font-mono text-7xl font-bold tracking-widest">
            {/* TODO: Muestra las horas, minutos y segundos del estado. */}
            <span>00</span>
            <span>:</span>
            <span>00</span>
            <span>:</span>
            <span>00</span>
          </div>
          <div className="mt-2 text-lg text-gray-300">
            {/* TODO: Muestra la fecha del estado. */}
            Fecha actual
          </div>
        </div>
      </div>
    </div>
  );
};
