import { useState } from "react";
import { CustomJumbotron } from '../shared/custom/CustomJumbotron';
import styles from "./WordReverser.module.css";

export const WordReverser = () => {
  // TODO: Crea un estado llamado `text` para almacenar el valor del input.
  // Inicialízalo como un string vacío.

  // TODO: Crea una variable `reversedText`.
  // Para calcular su valor, toma el `text` del estado y encadena los siguientes métodos de string:
  // 1. .split('') para convertir el string en un array de caracteres.
  // 2. .reverse() para invertir el orden del array.
  // 3. .join('') para volver a unir los caracteres en un string.
  const reversedText = "";

  return (
    <div className={styles.mainContainer}>
      <CustomJumbotron title="Word Reverser"/>
      <div className={styles.container}>
        <input
          type="text"
          // TODO: Vincula el `value` de este input con el estado `text`.
          value={""}
          // TODO: Añade un manejador `onChange` que actualice el estado `text`
          // con el valor actual del input (e.target.value).
          onChange={() => {}}
          placeholder="Escribe algo aquí..."
          className={styles.input}
        />
        <p className={styles.resultLabel}>Texto invertido:</p>
        {/* TODO: Muestra la variable `reversedText` en este párrafo. */}
        <p className={styles.resultText}>{""}</p>
      </div>
    </div>
  );
};