import { useState } from "react";
import { CustomJumbotron } from '../shared/custom/CustomJumbotron';
import styles from "./WordReverser.module.css";

export const WordReverser = () => {
  const [text, setText] = useState<string>("");

  const reversedText = text.split("").reverse().join("");

  return (
    <div className={styles.mainContainer}>
      <CustomJumbotron title="Word Reverser"/>
      <div className={styles.container}>
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Escribe algo aquí..."
          className={styles.input}
        />
        <p className={styles.resultLabel}>Texto invertido:</p>
        <p className={styles.resultText}>{reversedText}</p>
      </div>
    </div>
  );
};
