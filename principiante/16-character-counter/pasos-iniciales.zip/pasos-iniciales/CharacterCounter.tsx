import { CustomJumbotron } from "../shared/custom/CustomJumbotron";
import { useInputCounter } from "./hooks/useInputCounter";
import { cn } from '../lib/utils';


export const CharacterCounter = () => {
  
  // TODO: Consume el hook `useInputCounter` para obtener los valores y funciones que necesitas.

  return (
    <>
      <CustomJumbotron title="Character Counter" />

      <div className="flex flex-col min-h-screen items-center p-4">
        <div className="w-full max-w-md rounded-lg bg-white p-6 shadow-md">
          
          <textarea
            className="w-full rounded-md border border-gray-300 p-3 text-lg text-gray-700 shadow-sm transition-colors focus:border-blue-500 focus:ring-2 focus:ring-blue-500"
            placeholder="Escribe algo aquí..."
            value={''}
            onChange={()=> {}}
            maxLength={1}
            rows={5}
          />

          
          <div className="mt-3 flex justify-between text-sm font-medium">
            <span className="text-gray-500">
              {/* TODO: Muestra el número de caracteres actual y el límite. Ej: "0 / 50" */}
            </span>
            <span
              // TODO: Aplica un estilo condicional para que el texto sea rojo (`text-red-500`)
              // si quedan menos de 20 caracteres. De lo contrario, usa `text-gray-500`.
              className={cn(
                'transition-colors',
              )}
            >
              {/* TODO: Muestra el número de caracteres restantes. */}
              Restantes: 1
            </span>
          </div>
        </div>
      </div>
    </>
  );
};
