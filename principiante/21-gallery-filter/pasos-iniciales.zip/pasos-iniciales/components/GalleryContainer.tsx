import { useState } from 'react';
import { FilterMenu } from './FilterMenu';
import { GalleryGrid } from './GalleryGrid';
import { galleryItems } from '../data/gallery-data.mock';

// Obtenemos una lista de categorías únicas para pasarla al menú.
// Se usa un Set para evitar duplicados y lo convertimos de nuevo a un array.
const allCategories = ['all', ...new Set(galleryItems.map(item => item.category))];

export const GalleryContainer = () => {

  // TODO: Crea un estado `activeFilter` para guardar el string de la categoría activa.

  // TODO: Crea una variable `filteredItems` que se derive del estado `activeFilter`.
  // - Si `activeFilter` es 'all', `filteredItems` debe ser igual al array `galleryItems` completo.
  // - Si `activeFilter` es otra categoría, `filteredItems` debe contener solo los
  //   ítems de `galleryItems` que pertenezcan a esa categoría.
  const filteredItems = galleryItems; // <- Valor temporal

  return (
    <div className="min-h-screen text-white font-sans">
      <div className="container mx-auto px-4 py-8">

        <main>
          {/* TODO: Pasa las props necesarias al componente `FilterMenu`. */}
          <FilterMenu 
            categories={}
            activeFilter={''} // <- Valor temporal
            setActiveFilter={() => {}}
          />

          {/* TODO: Pasa la lista de ítems ya filtrados al componente `GalleryGrid`. */}
          <GalleryGrid />
        </main>
      </div>
    </div>
  );
}