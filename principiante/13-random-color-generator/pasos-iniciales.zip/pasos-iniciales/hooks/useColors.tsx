import { useState } from "react";
import { generateHexColor } from "../helpers/generate-hex-color.helper";

export const useColors = () => {
  // TODO: Crea un estado `currentColor` para almacenar el string del color.
  // Inicialízalo con un color por defecto (ej. '#FFFFFF') o con un color aleatorio
  // llamando a `generateHexColor()`.

  const handleGenerateColor = () => {
    // TODO: Implementa la lógica para generar un nuevo color y actualizar el estado.
    // 1. Llama a la función `generateHexColor` para obtener un nuevo color.
    // 2. Actualiza el estado `currentColor` con el nuevo valor.
  };

  return {
    // Properties
    // TODO: Retorna el estado `currentColor`.
    currentColor: '#FFFFFF', // <- Valor temporal

    // Methods
    handleGenerateColor,
  };
};