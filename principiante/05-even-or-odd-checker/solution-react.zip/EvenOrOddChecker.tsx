import { useState } from "react";
import { CustomJumbotron } from '../shared/custom/CustomJumbotron';
import styles from "./EvenOrOddChecker.module.css";

type ResultType = "par" | "inpar" | "invalido" | null;

export const EvenOrOddChecker = () => {
  const [inputValue, setInputValue] = useState<string>("");
  const [resultType, setResultType] = useState<ResultType>(null);

  const checkNumber = () => {
    if (inputValue.trim() === "" || isNaN(Number(inputValue))) {
      setResultType("invalido");
      return;
    }

    const number = parseInt(inputValue, 10);
    setResultType(number % 2 === 0 ? "par" : "inpar");
  };

  const getResult = () => {
    switch (resultType) {
      case "par":
        return <p className={`${styles.result} ${styles.even}`}>Es Par</p>;
      case "inpar":
        return <p className={`${styles.result} ${styles.odd}`}>Es Impar</p>;
      case "invalido":
        return (
          <p className={`${styles.result} ${styles.invalid}`}>
            Entrada no válida
          </p>
        );
      default:
        return <p className={styles.result}>Esperando un número...</p>;
    }
  };

  return (
    <div className={styles.mainContainer}>
      <CustomJumbotron title="Verificador Par o Impar"/>
      <div className={styles.container}>
        <div className={styles.controls}>
          <input
            type="number"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Ingresa un número"
            className={styles.input}
          />
          <button onClick={checkNumber} className={styles.button}>
            Verificar
          </button>
        </div>
        <div className={styles.resultContainer}>{getResult()}</div>
      </div>
    </div>
  );
};
