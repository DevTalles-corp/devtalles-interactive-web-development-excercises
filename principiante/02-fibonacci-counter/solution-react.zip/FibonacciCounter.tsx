import { useState } from "react";
import { CustomJumbotron } from '../shared/custom/CustomJumbotron';
import styles from "./FibonacciCounter.module.css";

/**
 * Calcula el número n de la secuencia de Fibonacci.
*/
const getFibonacci = (n: number): number => {
  if (n <= 1) return n;

  let a = 0;
  let b = 1;

  for (let i = 2; i <= n; i++) {
    const temp = a + b;
    a = b;
    b = temp;
  }

  return b;
};


export const FibonacciCounter = () => {
  const [index, setIndex] = useState<number>(0);
  
  const handlePrev = () => {
    setIndex((prevIndex) => (prevIndex > 0 ? prevIndex - 1 : 0));
  };

  const handleNext = () => {
    setIndex((prevIndex) => prevIndex + 1);
  };

  const fibonacciNumber = getFibonacci(index);

  return (
    <div className={styles.mainContainer}>
      <CustomJumbotron title="Contador de Serie Fibonacci" />
      <div className={styles.container}>
        <p className={styles.numberDisplay}>{fibonacciNumber}</p>
        <div className={styles.buttonGroup}>
          <button
            onClick={handlePrev}
            disabled={index === 0}
            className={styles.button}
          >
            Anterior
          </button>
          <button onClick={handleNext} className={styles.button}>
            Siguiente
          </button>
        </div>
      </div>
    </div>
  );
};