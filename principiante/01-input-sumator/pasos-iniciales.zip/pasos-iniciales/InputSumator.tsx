import { useState } from "react";
import { CustomJumbotron } from '../shared/custom/CustomJumbotron';
import styles from "./InputSumator.module.css";

export const InputSumator = () => {
  // TODO: Crea un estado llamado `num1` para el primer input, inicializado como un string vacío.
  // TODO: Crea un estado llamado `num2` para el segundo input, inicializado como un string vacío.

  // TODO: Calcula la suma.
  // 1. Convierte `num1` y `num2` a números. Puedes usar `Number()`.
  // 2. Si el resultado de la conversión no es un número (por ejemplo, si el input está vacío), deberías tratarlo como 0.
  // 3. Almacena el resultado de la suma en una variable.
  const sum = 0;

  return (
    <div className={styles.mainContainer}>
      <CustomJumbotron title="Sumador de Inputs"/>
      <div className={styles.container}>
        <div className={styles.inputGroup}>
          <input
            type="number"
            // TODO: Vincula el `value` de este input con el estado `num1`.
            value={0}
            // TODO: Añade un manejador `onChange` que actualice el estado `num1`
            // con el valor que el usuario escribe (e.target.value).
            onChange={() => {}}
            className={styles.input}
            aria-label="Primer número"
          />
          <span className={styles.operator}>+</span>
          <input
            type="number"
            // TODO: Vincula el `value` de este input con el estado `num2`.
            value={0}
            // TODO: Añade un manejador `onChange` que actualice el estado `num2`.
            onChange={() => {}}
            className={styles.input}
            aria-label="Segundo número"
          />
        </div>
        <div className={styles.result}>
          <span className={styles.equals}>=</span>
          <p className={styles.sum}>{sum}</p>
        </div>
      </div>
    </div>
  );
};