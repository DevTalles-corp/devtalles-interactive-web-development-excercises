import { useState } from "react";
import { CustomJumbotron } from '../shared/custom/CustomJumbotron';
import styles from "./InputSumator.module.css";

export const InputSumator = () => {
  const [num1, setNum1] = useState<string>("");
  const [num2, setNum2] = useState<string>("");
  
  const number1 = Number(num1) || 0;
  const number2 = Number(num2) || 0;
  const sum = number1 + number2;

  return (
    <div className={styles.mainContainer}>
      <CustomJumbotron title="Sumador de Inputs"/>
      <div className={styles.container}>
        <div className={styles.inputGroup}>
          <input
            type="number"
            value={num1}
            onChange={(e) => setNum1(e.target.value)}
            className={styles.input}
            aria-label="Primer número"
          />
          <span className={styles.operator}>+</span>
          <input
            type="number"
            value={num2}
            onChange={(e) => setNum2(e.target.value)}
            className={styles.input}
            aria-label="Segundo número"
          />
        </div>
        <div className={styles.result}>
          <span className={styles.equals}>=</span>
          <p className={styles.sum}>{sum}</p>
        </div>
      </div>
    </div>
  );
};
