import { LoginForm } from './LoginForm';
import { Illustration } from './Illustration';
import { CloseButton } from './CloseButton';
import { SocialLoginButtons } from './SocialLoginButtons';
import illustration from '../images/image.jpg';
import styles from '../LoginModal.module.css';

export const LoginCard = () => {
  return (
    <div className={styles.cardContainer}>
      <div className={styles.leftSide}>
        <LoginForm />

        {/* Border */}
        <div className={styles.divider}></div>
        <p className={styles.socialLoginText}>or log in with</p>

        <SocialLoginButtons />
      </div>

      <Illustration src={illustration} alt='Decorative' />
      <CloseButton />
    </div>
  );
};