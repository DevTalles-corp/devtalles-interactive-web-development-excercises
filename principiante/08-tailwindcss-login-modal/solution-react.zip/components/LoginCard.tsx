import { LoginForm } from './LoginForm';
import { Illustration } from './Illustration';
import { CloseButton } from './CloseButton';
import { SocialLoginButtons } from './SocialLoginButtons';
import illustration from '../images/image.jpg';

export const LoginCard = () => {
  return (
    <div className="relative flex flex-col m-6 space-y-10 bg-white shadow-2xl rounded-2xl md:flex-row md:space-y-0 md:m-0">
      <div className="p-6 md:p-20">
        <LoginForm />

        {/* Border */}
        <div className="mt-12 border-b border-b-gray-300"></div>

        <p className="py-6 text-sm font-thin text-center text-gray-400">
          or log in with
        </p>

        <SocialLoginButtons />
      </div>

      <Illustration src={illustration} alt='Decorative' />
      <CloseButton />
    </div>
  );
};