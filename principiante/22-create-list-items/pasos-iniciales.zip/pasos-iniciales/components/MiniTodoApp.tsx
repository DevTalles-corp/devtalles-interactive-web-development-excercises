import { useState } from 'react';
import { ItemForm } from './ItemForm';
import { ItemList } from './ItemList';

export interface Item {
  id: number;
  text: string;
}

const itemList: Item[] = [
  // { id: 1, text: 'Aprender JavaScript' },
  // { id: 2, text: 'Practicar con TypeScript' },
  // { id: 3, text: 'Estilizar con Tailwind CSS' },
]

export const MiniTodoApp = () => {

  // TODO: Crea un estado `newItemText` para controlar el valor del input.

  // TODO: Crea un estado `items` para almacenar la lista de tareas.

  const handleAddItem = () => {
    // TODO: Implementa la lógica para añadir un nuevo ítem a la lista.
    // 1. No hagas nada si `newItemText` está vacío (después de quitarle los espacios en blanco).
    // 2. Crea un nuevo objeto `Item` con un `id` único (puedes usar `Date.now()`) y el `text`.
    // 3. Actualiza el estado `items` añadiendo el nuevo ítem de forma inmutable.
    // 4. Resetea `newItemText` a un string vacío.
  };

  return (
    <div className="text-white font-sans flex items-center">
      <div className="bg-slate-800 p-8 rounded-xl shadow-2xl w-full min-w-lg">
        <main>
          {/* TODO: Pasa las props necesarias al componente `ItemForm`.*/}
          <ItemForm />

          {/* TODO: Pasa la lista de `items` al componente `ItemList`. */}
          <ItemList />
        </main>
      </div>
    </div>
  );
}