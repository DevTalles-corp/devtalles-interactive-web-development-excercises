import { InputSumator } from "./01-input-sumator/InputSumator";
// import { FibonacciCounter } from "./02-fibonacci-counter/FibonacciCounter";
// import { TemperatureConverter } from "./03-temperature-converter/TemperatureConverter";

export const App = () => {
  return (
    <div className="bg-gradient">
      <InputSumator />
    </div>
  );
};
