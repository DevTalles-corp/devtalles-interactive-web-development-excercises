import { GalleryItem } from "./GalleryItem";
import { galleryData } from "../data/gallery-data.mock";

export const GalleryGrid = () => {
  return (
    <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
      {galleryData.map((item) => (
        <GalleryItem key={item.id} {...item} />
      ))}
    </div>
  );
};
