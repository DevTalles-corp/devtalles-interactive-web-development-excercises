import { galleryData } from '../data/gallery-data.mock';
import { GalleryItem } from './GalleryItem';
import styles from '../ImageGallery.module.css'

export const GalleryGrid = () => {
  return (
    <div className={styles.galleryGrid}>
      {galleryData.map((item) => (
        <GalleryItem key={item.id} {...item} />
      ))}
    </div>
  );
};
