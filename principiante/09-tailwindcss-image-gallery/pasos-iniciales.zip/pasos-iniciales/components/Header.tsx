import styles from '../ImageGallery.module.css'

const menuItems = ['Vector', 'Illustrations', 'Images', 'Icons'];

export const Header = () => {
  return (
    <>
      {/* -- Menú -- */}
      <div className={styles.menuContainer}>
        {menuItems.map((item) => (
          <div key={item} className={styles.menuItem}>
            <a href="#">{item}</a>
            <div className={styles.menuUnderline}></div>
          </div>
        ))}
      </div>

      {/* -- Buscador -- */}
      <div className={styles.searchContainer}>
        <div className={styles.inputContainer}>
          <input type="text" className={styles.input} placeholder="Search" />
          <button>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className={styles.searchIcon}
              viewBox="0 0 24 24"
              strokeWidth="1.5"
              stroke="currentColor"
              fill="none"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path stroke="none" d="M0 0h24v24H0z" fill="none" />
              <circle cx="10" cy="10" r="7" />
              <line x1="21" y1="21" x2="15" y2="15" />
            </svg>
          </button>
        </div>
        <button className={styles.uploadButton}>Upload</button>
      </div>
    </>
  );
};
