interface Props {
  iconSrc: string;
  text: string;
}

export const ActionButton = ({ iconSrc, text }: Props) => {
  return (
    <button
      className="flex items-center justify-center py-3 px-5 space-x-3 border-2 border-gray-300 rounded-lg shadow-sm hover:bg-opacity-30 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-150"
    >
      <img src={iconSrc} alt="" className="w-8" />
      <span>{text}</span>
    </button>
  );
};