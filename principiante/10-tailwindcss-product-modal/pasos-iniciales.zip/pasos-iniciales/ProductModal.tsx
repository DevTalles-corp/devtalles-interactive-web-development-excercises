import { ActionButton } from "./components/ActionButton";
import headphone from "./images/headphone.png";
import weight from "./images/weight.png";
import heart from "./images/heart.png";
import styles from "./ProductModal.module.css";

export const ProductModal = () => {
  return (
    <div className={styles.globalContainer}>
      <div className={styles.cardContainer}>
        <div>
          <img
            src={headphone}
            alt="Razer Kraken Kitty Gaming Headset"
            className={styles.productImage}
          />
        </div>

        <div className={styles.contentContainer}>
          <div className={styles.labelContainer}>
            <div>
              <div className={styles.shippingLabel}>Free Shipping</div>
            </div>
            <div className={styles.title}>
              Razer Kraken Kitty Edt Gaming Headset Quartz
            </div>
          </div>

          <div className={styles.priceContainer}>
            <p className={styles.oldPrice}>$799</p>
            <p className={styles.newPrice}>$599</p>
            <p className={styles.offerText}>
              This offer is valid until April 3rd or as long as stock lasts!
            </p>
          </div>

          <div className={styles.mainButtonGroup}>
            <button className={styles.mainButton}>
              <div className={styles.mainButtonInner}>Add to cart</div>
            </button>
          </div>

          <div className={styles.stockContainer}>
            <div className={styles.stockDot}></div>
            <div className={styles.stockText}>50+ pcs. in stock</div>
          </div>

          <div className={styles.bottomButtonsContainer}>
            <ActionButton iconSrc={weight} text="Add to cart" />
            <ActionButton iconSrc={heart} text="Add to wishlist" />
          </div>
        </div>
      </div>
    </div>
  );
};
