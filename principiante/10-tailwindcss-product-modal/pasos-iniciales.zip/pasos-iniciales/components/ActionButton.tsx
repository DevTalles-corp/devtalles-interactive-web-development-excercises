import styles from '../ProductModal.module.css';

interface Props {
  iconSrc: string;
  text: string;
}

export const ActionButton = ({ iconSrc, text }: Props) => {
  return (
    <button className={styles.actionButton}>
      <img src={iconSrc} alt="" />
      <span>{text}</span>
    </button>
  );
};