import { mapRange } from '../helpers/mapRange';
import { useProgress } from '../hooks/useProgress';

export function MainBlurryLoadingEffect() {

  // TODO: Llama al custom hook 'useProgress' para obtener el valor del progreso.

  // TODO: Usando la función 'mapRange', calcula el valor del desenfoque (blur).
  // Debe mapear el rango de progreso (0-100) a un rango de desenfoque (ej. 30 a 0).
  const blurEffect = 0;

  // TODO: Usando la función 'mapRange', calcula el valor de la opacidad del texto.
  // Debe mapear el rango de progreso (0-100) a un rango de opacidad (1 a 0).
  const textOpacity = 1;


  return (
    <div className="relative w-10/12 h-10/12">
      
      <div
        className="absolute top-0 left-0 h-full w-full bg-[url('https://images.unsplash.com/photo-1597840900616-664e930c29df?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D')] bg-cover bg-center"
        style={{
          // TODO: Aplica el desenfoque (blurEffect) calculado dinámicamente.
          // La propiedad CSS es `filter`. Ejemplo: filter: `blur(10px)`
        }}
      />

      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-6xl font-bold text-white"
        style={{
          // TODO: Aplica la opacidad (textOpacity) calculada dinámicamente.
          // La propiedad CSS es `opacity`
        }}
      >
        {/* TODO: Muestra el progreso actual seguido del símbolo '%'. */}
      </div>
    </div>
  );
}