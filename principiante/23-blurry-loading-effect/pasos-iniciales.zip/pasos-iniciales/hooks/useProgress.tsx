import { useEffect, useState } from "react";

export const useProgress = () => {

  // TODO: Crea un estado 'progress' para almacenar el progreso de la carga, inicializado en 0.
  
  // TODO: Utiliza un useEffect para manejar el ciclo de vida del temporizador.
  // 1. Inicia un `setInterval` que se ejecute cada 30 milisegundos cuando el componente se monte.
  // 2. Dentro del intervalo, incrementa el estado 'progress' en 1.
  // 3. Si 'progress' llega a 100, detén el intervalo usando `clearInterval`.
  // 4. Implementa la función de limpieza de useEffect para detener el intervalo si el componente se desmonta.

  return {
    // TODO: Retorna el estado 'progress' para que otros componentes puedan usarlo.
    progress: 0,
  }
}