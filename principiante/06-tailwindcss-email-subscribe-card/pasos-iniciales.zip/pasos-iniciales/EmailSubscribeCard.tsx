
import image from './images/image.jpg';
import styles from './EmailSubscribeCard.module.css';

export const EmailSubscribeCard = () => {
  return (
    <div className={styles.backgroundContainer}>
      {/* Tarjeta */}
      <div className={styles.card}>
        {/* Contenedor flexible para la imagen y el contenido */}
        <div className={styles.flexContainer}>
          {/* Imagen */}
          <img
            src={image}
            alt="Mujer haciendo ejercicio"
            className={styles.cardImage}
          />

          {/* Contenido de texto y formulario */}
          <div className={styles.content}>
            <h2 className={styles.heading}>
              Get diet and fitness tips in your inbox
            </h2>

            <p className={styles.paragraph}>
              Eat better and exercise better. Sign up for the Diet&Fitness
              newsletter.
            </p>

            {/* Contenedor del formulario */}
            <div className={styles.formContainer}>
              <input
                type="email"
                placeholder="Enter your email address"
                className={styles.emailInput}
              />

              <button className={styles.subscribeButton}>
                Subscribe
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};