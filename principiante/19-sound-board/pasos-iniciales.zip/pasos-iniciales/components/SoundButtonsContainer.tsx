import { useRef } from "react";
import { SoundButton } from "./SoundButton";
import { sounds } from "../data/sounds";

export const SoundButtonsContainer = () => {

  // TODO: Crea una referencia (`useRef`) para guardar el elemento de audio que se está reproduciendo actualmente.

  const handlePlaySound = (soundId: string) => {
    // TODO: Implementa la lógica para reproducir el sonido.
    // 1. Detén el sonido que se está reproduciendo actualmente (si hay uno).
    // 2. Encuentra el nuevo elemento de audio en el DOM usando su `soundId`.
    // 3. Si el audio existe, reprodúcelo (`.play()`).
    // 4. Actualiza la referencia para que apunte al nuevo audio que se está reproduciendo.
  };

  return (
    <div className="flex flex-wrap items-center justify-center gap-4">
      {sounds.map((sound) => (
        <SoundButton
          key={sound.id}
          sound={sound}
          icon={sound.icon}
          onPlaySound={() => {}}
        />
      ))}
    </div>
  );
};