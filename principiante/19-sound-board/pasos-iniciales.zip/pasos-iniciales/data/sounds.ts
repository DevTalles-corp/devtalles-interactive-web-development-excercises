export interface Sound {
  icon: string;
  id: string;
  file: string;
  name: string;
}

// Para este ejercicio, utilizaremos URLs de sonidos de ejemplo
export const sounds: Sound[] = [
  { id: 'applause', icon: '👏🏻', name: 'Applause', file: '' },
  { id: 'boo', icon: '👎🏻', name: 'Boo', file: '' },
  { id: 'gasp', icon: '😮', name: 'Gasp', file: '' },
  { id: 'tada', icon: '🎉', name: 'Tada', file: '' },
  { id: 'victory', icon: '✌🏻', name: 'Victory', file: '' },
  { id: 'wrong', icon: '❌', name: 'Wrong', file: '' },
];
