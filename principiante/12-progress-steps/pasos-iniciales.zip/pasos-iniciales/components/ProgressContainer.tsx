import { StepCircle } from "./StepCircle";
import { NavButton } from "./NavButton";
import { useSteps } from "../hooks/useSteps";

export const ProgressContainer = () => {
  // El hook `useSteps` te dará todo lo que necesitas.
  const { } = useSteps();

  return (
    <div className="flex flex-col items-center justify-center p-8 font-sans">
      <div className="w-full max-w-sm">
        <div className="relative flex items-center justify-between">
          {/* Barra de progreso vacía */}
          <div className="absolute top-1/2 h-1 w-full -translate-y-1/2 bg-gray-300" />

          {/* Barra de progreso activa */}
          {/* TODO: Aplica el `progressWidth` del hook al estilo `width` de este div. */}
          <div
            className="absolute top-1/2 h-1 -translate-y-1/2 bg-blue-600 transition-all duration-500 ease-in-out"
            style={{}}
          />

          {steps.map((step) => (
            // TODO: Determina si el círculo debe estar activo.
            // Un círculo está activo si su número de paso es menor o igual al `currentStep`.
            <StepCircle key={step} step={step} isActive={false} />
          ))}
        </div>

        <div className="mt-8 flex justify-center gap-4">
          {/* TODO: Conecta el evento `onClick` con `handlePrev` y gestiona el estado `disabled`. */}
          {/* El botón debe estar deshabilitado si `currentStep` es 1. */}
          <NavButton onClick={() => {}} disabled={false}>
            Anterior
          </NavButton>

          {/* TODO: Conecta el evento `onClick` con `handleNext` y gestiona el estado `disabled`. */}
          {/* El botón debe estar deshabilitado si `currentStep` es igual al número total de pasos. */}
          <NavButton onClick={() => {}} disabled={false}>
            Siguiente
          </NavButton>
        </div>
      </div>
    </div>
  );
};