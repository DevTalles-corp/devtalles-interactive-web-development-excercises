## 🚀 Instalación y Configuración

### Prerrequisitos

- **Node.js** 18.0+ 
- **npm** 9.0+ o **yarn** 1.22+

### Pasos de Instalación

1. **Instala las dependencias**
   ```bash
   npm install
   # o
   yarn install
   ```

2. **Inicia el servidor de desarrollo**
   ```bash
   npm run dev
   # o
   yarn dev
   ```

3. **Abre en el navegador web**
   ```
   http://localhost:5173
   ```