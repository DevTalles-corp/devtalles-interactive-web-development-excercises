import { useEffect, useRef, useState } from "react";
import { useSearchDebounce } from "./useSearchDebounce";
import { getCountryNameApiAction } from "../actions/get-country-name-api.action";
import { getCountryNameLocalAction } from "../actions/get-country-name-local.action";

type SearchStatus = 'idle' | 'loading' | 'success' | 'error';

export const useAutoCompleteCountry = (dataSourceType : 'local' | 'api') => {
  const [inputValue, setInputValue] = useState<string>("");
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [status, setStatus] = useState<SearchStatus>("idle");
  const isSelectionMade = useRef(false);

  const debouncedInputValue = useSearchDebounce(inputValue, 500);

  useEffect(() => {
    if (isSelectionMade.current) {
      isSelectionMade.current = false;
      return;
    }

    if (!debouncedInputValue) {
      setSuggestions([]);
      setStatus('idle');
      return;
    }

    const controller = new AbortController();
    const { signal } = controller;

    
    const handleSearch = async () => {
      setStatus('loading');

      try {
        let results: string[] = [];

        if(dataSourceType === 'local') {
          results = await getCountryNameLocalAction(debouncedInputValue, signal);
        } else {
          results = await getCountryNameApiAction(debouncedInputValue, signal);
        }

        if (signal.aborted) return;
        setSuggestions(results);
        setStatus('success');

      } catch (error) {
        console.error('Error durante la búsqueda:', error);
        setSuggestions([]);
        setStatus('error');
      }
    }

    handleSearch();
    
    return () => {
      controller.abort();
    };
  }, [debouncedInputValue, dataSourceType]);

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(event.target.value);
  };

  const handleSelected = (selectedValue: string) => {
    isSelectionMade.current = true;
    setInputValue(selectedValue);
    setSuggestions([]);
    setStatus('idle');
  }
  

  return {
    // Properties
    debouncedInputValue,
    suggestions,
    status,
    inputValue,

    //Methods
    handleInputChange,
    handleSelected
  };
};
