import { RESTCountriesResponse } from '../types/restcountries.response';

export const getCountryNameApiAction = async (query: string, signal: AbortSignal) => {
  // TODO: Implementa la llamada a la API `https://restcountries.com`
  // - Usa `fetch` para hacer la petición a `https://restcountries.com/v3.1/translation/${query}`.
  // - Revisa en la API qué hace este endpoint y qué parámetros recibe.
  // - Pasa el `signal` al objeto de opciones del fetch.
  // - Usa un bloque try/catch para manejar errores de red.
  // - Si la respuesta tiene un status 404, devuelve un array vacío `[]`.
  // - Si la respuesta no es `ok` (y no es 404), lanza un error.
  // - Si la respuesta es exitosa, convierte los datos a JSON.
  // - Mapea los resultados para devolver un array de strings con los nombres comunes en español.
  //   (ej. `data.map(country => country.translations['spa'].common)`)
  // - En el catch, si no es un error de aborto, vuelve a lanzar el error.

  return []; // Devuelve un array vacío por defecto.
};