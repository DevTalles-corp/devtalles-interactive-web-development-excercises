import { useEffect, useState, useRef } from "react";
import { useSearchDebounce } from "./useSearchDebounce";
import { getCountryNameLocalAction } from "../actions/get-country-name-local.action";

type SearchStatus = 'idle' | 'loading' | 'success' | 'error';

export const useAutoCompleteCountry = (dataSourceType : 'local' | 'api') => {
  const [inputValue, setInputValue] = useState('');
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [status, setStatus] = useState<SearchStatus>('idle');
  
  const isSelectionMade = useRef(false);

  // TODO: Llama al hook `useSearchDebounce` para obtener el valor del input con retardo.
  const debouncedInputValue = ''; // Reemplaza esto con la llamada al hook.

  useEffect(() => {
    // TODO: Implementa la lógica principal de búsqueda.
    // - Si la bandera `isSelectionMade.current` es true, reseteala a false y detén el efecto.
    // - Si `debouncedInputValue` está vacío, limpia las sugerencias y resetea el estado a 'idle'.
    // - Crea un `AbortController` para cancelar peticiones.
    // - Define una función `handleSearch` asíncrona.
    //   - Dentro de `handleSearch`:
    //     - Cambia el estado a 'loading'.
    //     - Usa un bloque try/catch.
    //     - Llama a la acción correspondiente (`getCountryNameApiAction` o `getCountryNameLocalAction`)
    //       pasando el valor debounceado y la señal del AbortController.
    //     - Si la petición tiene éxito, actualiza `suggestions` y cambia el estado a 'success'.
    //     - En el `catch`, si no es un error de aborto, actualiza el estado a 'error'.
    // - Llama a `handleSearch`.
    // - Retorna una función de limpieza que llame a `controller.abort()`.

  }, [debouncedInputValue, dataSourceType]);

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    // TODO: Actualiza el estado `inputValue` con el valor del input.
  };

  const handleSelected = (selectedValue: string) => {
    // TODO: Implementa la lógica para cuando se selecciona una sugerencia.
    // - Activa la bandera `isSelectionMade.current`.
    // - Actualiza el `inputValue`.
    // - Limpia los estados.
  };
  
  // Devuelve los estados y funciones que el componente necesita.
  return {
    // Properties
    inputValue,
    suggestions,
    status,

    // Methods
    debouncedInputValue,
    handleInputChange,
    handleSelected,
  };
};