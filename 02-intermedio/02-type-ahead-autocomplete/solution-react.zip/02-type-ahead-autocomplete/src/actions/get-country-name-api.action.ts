import type { RESTCountriesResponse } from "../types/restcountries.response";

export const getCountryNameApiAction = async (debouncedInputValue: string, signal: AbortSignal ) => {

  let results: string[] = [];
  try {
    const response = await fetch(
      `https://restcountries.com/v3.1/translation/${debouncedInputValue}`,
      { signal }
    );

    if (response.status === 404) {
      return [];
    }

    if ( !response.ok ) throw new Error("Error en la respuesta de la API");

    const data: RESTCountriesResponse[] = await response.json();
    if (signal.aborted) return [];
    results = data.map(country => country.translations['spa'].common);

  } catch (error) {
    // Ignoramos el error de aborto, ya que es esperado
    if ((error as Error).name === 'AbortError') {
      return [];
    }
    console.error(error);
    throw error;
  }

  return results;
};
