import { countries } from "../data/countries-data.mock";

export const getCountryNameLocalAction = async (debouncedInputValue: string, signal: AbortSignal ) => {

  let results: string[] = [];

  try {
    await new Promise(resolve => setTimeout(resolve, 300)); // Simular latencia
    if (signal.aborted) return []; // Comprobar si la petición fue cancelada
    results = countries.filter(country =>
      country.toLowerCase().includes(debouncedInputValue.toLowerCase())
    );

  } catch (error) {
    // Ignoramos el error de aborto, ya que es esperado
    if ((error as Error).name === 'AbortError') {
      console.log('Búsqueda cancelada.');
      return [];
    }
    console.error('Error en la búsqueda:', error);
  }

  return results;
};
