import './index.css'
import { TypeAheadAutocomplete } from './components/TypeAheadAutocomplete';
import { CustomJumbotron } from './components/shared/CustomJumbotron';

export const App = () => {

  return (
    <div className='bg-gradient flex flex-col gap-10 text-white'>
      <CustomJumbotron
        title='Typeahead Autocomplete'
        description='Escribe el nombre de un país y te mostrará las sugerencias.'
      />
      <TypeAheadAutocomplete dataSourceType='api' />
    </div>
  )
}
