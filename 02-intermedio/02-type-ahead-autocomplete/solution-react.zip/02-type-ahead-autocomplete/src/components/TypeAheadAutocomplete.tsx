import { SearchInput } from './SearchInput';
import { SuggestionsList } from './SuggestionsList';
import { useAutoCompleteCountry } from '../hooks/useAutoCompleteCountry';

interface Props {
  dataSourceType: 'local' | 'api';
};

export const TypeAheadAutocomplete = ({ dataSourceType }: Props) => {

  const {
    debouncedInputValue,
    handleInputChange,
    handleSelected,
    inputValue,
    status,
    suggestions
  } = useAutoCompleteCountry(dataSourceType);

  return (
    <div className="relative w-full max-w-md mx-auto">
      <SearchInput 
        value={inputValue} 
        onChange={handleInputChange} 
        status={status} 
      />
      {/* Mostramos la lista si tenemos resultados */}
      {status === 'success' && suggestions.length > 0 && (
        <SuggestionsList
          suggestions={suggestions}
          onSuggestionClick={handleSelected}
        />
      )}
      {/* Mensaje de "no encontrado" */}
      {status === 'success' && suggestions.length === 0 && debouncedInputValue && (
         <div className="absolute z-10 w-full mt-1 p-4 bg-white border border-gray-300 rounded-md shadow-lg text-gray-500">
           No se encontraron resultados.
         </div>
      )}
      {/* Mensaje de error */}
      {status === 'error' && (
        <div className="absolute z-10 w-full mt-1 p-4 bg-red-50 border border-red-300 text-red-700 rounded-md shadow-lg">
          Ocurrió un error al realizar la búsqueda.
        </div>
      )}
    </div>
  );
};