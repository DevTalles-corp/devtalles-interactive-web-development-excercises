export interface RESTCountriesResponse {
  translations: { [key: string]: Translation };
}

export interface Translation {
  official: string;
  common:   string;
}