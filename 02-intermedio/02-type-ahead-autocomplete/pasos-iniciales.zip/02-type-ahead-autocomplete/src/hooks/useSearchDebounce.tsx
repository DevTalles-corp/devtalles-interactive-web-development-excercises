import { useState, useEffect } from 'react';

export const useSearchDebounce = (value: string, delay: number): string => {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    // TODO: Implementa la lógica de debounce.
    // - Usa `setTimeout` para actualizar `debouncedValue` después del `delay` especificado.
    // - Retorna una función de limpieza que use `clearTimeout` para cancelar el temporizador
    //   si el `value` o el `delay` cambian antes de que se cumpla el tiempo.
    
  }, [value, delay]);

  return debouncedValue;
};