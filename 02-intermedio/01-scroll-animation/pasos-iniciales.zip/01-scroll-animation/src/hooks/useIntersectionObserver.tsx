import { useState, useEffect } from 'react';

interface ObserverOptions {
  root?: Element | null;
  rootMargin?: string;
  threshold?: number | number[];
}

export const useIntersectionObserver = (
  elementRef: React.RefObject<Element | null>,
  options: ObserverOptions = { threshold: 0.3 }
): boolean => {
  
  // TODO 1: Define un estado con `useState` para saber si el elemento es visible o no.
  // El valor inicial debe ser `false`.
  const isIntersecting = false;

  // TODO 2: Usa el hook `useEffect` para crear y gestionar el ciclo de vida del observer.
  useEffect(() => {
    // El observer solo debe crearse si `elementRef.current` existe.
    const element = elementRef.current;
    if (!element) return;

    // TODO 3: Crea la función callback para el observer.
    // Esta función se ejecutará cuando cambie la visibilidad del elemento observado.
    // Debe recibir un array de `entries`.
    const observerCallback = (/* Agrega los parámetros necesarios */) => {
      // TODO 4: Dentro del callback, comprueba si el elemento está intersectando.
      // - Si `entry.isIntersecting` es `true`:
      //   a) Actualiza el estado de `isIntersecting` a `true`.
      //   b) (Opcional, pero buena práctica) Haz que el observer deje de observar el elemento
      //      para no gastar recursos innecesariamente.
    };
    
    // TODO 5: Crea una nueva instancia de `IntersectionObserver`.
    // Pásale el callback que creaste y las `options`.
    const observer = new IntersectionObserver(/* ... */);

    // TODO 6: Inicia la observación sobre el elemento del DOM.
    // ... observer.observe(...)

    // TODO 7: Devuelve una función de limpieza para `useEffect`.
    // Esta función se ejecutará cuando el componente se desmonte.
    // Su objetivo es desconectar el observer para prevenir fugas de memoria.
    return () => {
      // ... observer.disconnect()
    };
    
  // El efecto debe volver a ejecutarse si la referencia o las opciones cambian.
  }, [elementRef, options]);

  // TODO 8: Devuelve el estado que indica si el elemento es visible.
  return isIntersecting;
};