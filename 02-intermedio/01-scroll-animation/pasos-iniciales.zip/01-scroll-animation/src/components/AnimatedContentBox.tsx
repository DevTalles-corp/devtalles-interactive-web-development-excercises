import { useRef } from "react";
import { ContentBox } from "./ContentBox";
import { useIntersectionObserver } from "../hooks/useIntersectionObserver";

export const AnimatedContentBox = ({ children }: { children: React.ReactNode }) => {
  const ref = useRef<HTMLDivElement>(null);
  // TODO: Obten el estado `isVisible` del hook useInterctionObserver y pásale la `ref`.

  return (
    <ContentBox ref={ref} isVisible={true}>
      {children}
    </ContentBox>
  );
};