import { ScrollAnimation } from "./components/ScrollAnimation";

export const App = () => {
  return (
    <div className="bg-gradient">
      <ScrollAnimation />
    </div>
  );
};