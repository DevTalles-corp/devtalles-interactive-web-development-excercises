import { Soundboard } from "./components/Soundboard";

export const App = () => {
  return (
    <div className="bg-gradient">
      <Soundboard />
    </div>
  );
};