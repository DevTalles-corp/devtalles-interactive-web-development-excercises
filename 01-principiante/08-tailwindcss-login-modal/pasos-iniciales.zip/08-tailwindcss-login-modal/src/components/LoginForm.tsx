import styles from './LoginModal.module.css';


export const LoginForm = () => {
  return (
    <>
      <h2 className={styles.title}>Log In</h2>
      <p className={styles.subtitle}>
        Log in to your account to upload or download pictures, videos or music.
      </p>
      <input
        type="text"
        className={styles.emailInput}
        placeholder="Enter your email address"
      />

      <div className={styles.middleContent}>
        <div className={styles.forgotPassword}>Forgot password</div>

        <button className={styles.nextButton}>
          <span>Next</span>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            strokeWidth="1.5"
            stroke="currentColor"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
            <line x1="5" y1="12" x2="19" y2="12" />
            <line x1="13" y1="18" x2="19" y2="12" />
            <line x1="13" y1="6" x2="19" y2="12" />
          </svg>
        </button>
      </div>
    </>
  );
};