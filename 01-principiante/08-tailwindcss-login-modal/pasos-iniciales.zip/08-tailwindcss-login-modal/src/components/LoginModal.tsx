import { LoginCard } from './LoginCard';
import styles from './LoginModal.module.css'; // Importa el CSS

export const LoginModal = () => {
  return (
    <div className={styles.globalContainer}>
      <LoginCard />
    </div>
  );
};