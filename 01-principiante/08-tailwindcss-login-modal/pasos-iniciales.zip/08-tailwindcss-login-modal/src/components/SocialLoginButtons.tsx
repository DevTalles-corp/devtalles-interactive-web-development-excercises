import facebookImage from '../images/facebook.png';
import googleImage from '../images/google.png';
import styles from './LoginModal.module.css';

export const SocialLoginButtons = () => {
  return (
    <div className={styles.socialButtonsContainer}>
      <button className={styles.socialButton}>
        <img src={facebookImage} alt="Facebook Login" />
        <span>Facebook</span>
      </button>
      <button className={styles.socialButton}>
        <img src={googleImage} alt="Google Login" />
        <span>Google</span>
      </button>
    </div>
  );
};