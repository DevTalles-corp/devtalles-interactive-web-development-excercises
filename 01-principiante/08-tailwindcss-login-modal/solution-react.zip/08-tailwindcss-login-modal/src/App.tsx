import { LoginModal } from './components/LoginModal';

export const App = () => {
  return (
    <div className="bg-gradient">
      <LoginModal />
    </div>
  );
};