import { LoginCard } from './LoginCard';

export const LoginModal = () => {
  return (
    <div className="flex items-center justify-center min-h-screen bg-rose-50">
      <LoginCard />
    </div>
  );
};