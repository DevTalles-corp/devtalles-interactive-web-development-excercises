interface Props {
  src: string;
  alt: string;
}

export const Illustration = ({ alt, src }: Props) => {
  return (
    <img
      src={src}
      alt={alt}
      className="w-[430px] hidden md:block"
    />
  );
};