import { ImageGallery } from './components/ImageGallery';

export const App = () => {
  return (
    <div className="bg-gradient">
      <ImageGallery />
    </div>
  );
};