// --- Datos de ejemplo para la galería ---

import image1 from '../images/image1.jpg';
import image2 from '../images/image2.jpg';
import image3 from '../images/image3.jpg';
import image4 from '../images/image4.jpg';
import image5 from '../images/image5.jpg';
import image6 from '../images/image6.jpg';

export const galleryData = [
  { id: 1, src: image1, title: 'Abstract Painting', likes: 245, shares: 35 },
  { id: 2, src: image2, title: 'Wood Structure', likes: 331, shares: 42 },
  { id: 3, src: image3, title: 'Morning Walk', likes: 198, shares: 21 },
  { id: 4, src: image4, title: 'City Skyline', likes: 450, shares: 87 },
  { id: 5, src: image5, title: 'Autumn Leaves', likes: 215, shares: 33 },
  { id: 6, src: image6, title: 'Calm Waters', likes: 380, shares: 55 },
];