import { GalleryGrid } from './GalleryGrid';
import { Header } from './Header';
import styles from './ImageGallery.module.css';

export const ImageGallery = () => {
  return (
    <div className={styles.pageContainer}>
      <div className={styles.card}>
        
        {/* Menú y barra de búsqueda */}
        <Header />

        {/* -- Grilla de Galería -- */}
        <GalleryGrid />
      </div>
    </div>
  );
};