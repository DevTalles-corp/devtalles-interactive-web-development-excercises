import bookmark from '../images/bookmark.svg'
import styles from './ImageGallery.module.css';

interface Props {
  src: string;
  title: string;
  likes: number;
  shares: number;
}
export const GalleryItem = ({ src, title, likes, shares }: Props) => (
  <div className={styles.galleryItem}>
    <img src={src} alt={title} />
    <div className={styles.imageOverlay}>
      <div className={styles.overlayContent}>
        <div className={styles.overlayText}>
          <p>{title}</p>
          <p>{likes} likes - {shares} Shares</p>
        </div>
        <div className={styles.bookmarkContainer}>
          <img src={bookmark} alt="bookmark" />
        </div>
      </div>
    </div>
  </div>
);