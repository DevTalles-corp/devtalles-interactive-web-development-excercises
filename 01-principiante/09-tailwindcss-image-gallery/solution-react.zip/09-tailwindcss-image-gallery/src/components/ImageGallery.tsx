import { GalleryGrid } from "./GalleryGrid";
import { Header } from "./Header";


export const ImageGallery = () => {
  return (
    <div className="flex items-center justify-center min-h-screen bg-cyan-50">
      <div className="bg-white p-6 m-3 space-y-10 shadow-2xl rounded-3xl md:p-40">
        {/* Menú y barra de búsqueda */}
        <Header />

        {/* -- Grilla de Galería -- */}
        <GalleryGrid />

      </div>
    </div>
  );
};
