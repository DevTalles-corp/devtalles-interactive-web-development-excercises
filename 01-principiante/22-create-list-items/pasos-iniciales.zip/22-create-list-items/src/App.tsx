import { CreateListItems } from "./components/CreateListItems";

export const App = () => {
  return (
    <div className="bg-gradient">
      <CreateListItems />
    </div>
  );
};