import { CharacterCounter } from "./components/CharacterCounter";

export const App = () => {
  return (
    <div className="bg-gradient">
      <CharacterCounter />
    </div>
  );
};