import { useState } from "react";

// Límite de caracteres definido para el ejercicio.
const CHAR_LIMIT = 150;

export const useInputCounter = () => {
  // TODO: Crea un estado `userInput` para almacenar el texto del textarea.

  // TODO: Implementa la función `handleChange`.
  // Esta función se llamará cada vez que el usuario escriba en el textarea.
  const handleChange = (event: React.ChangeEvent<HTMLTextAreaElement>) => {};

  // TODO: Calcula el número de caracteres actual basándote en `userInput`.
  const charCount = 0; // <- Valor temporal

  // TODO: Calcula el número de caracteres restantes.
  const remainingChars = 0; // <- Valor temporal

  return {
    // Properties
    // TODO: Retorna el estado `userInput`.
    userInput: "", // <- Valor temporal

    // Methods
    handleChange,

    // Computed (Valores calculados)
    charCount,
    remainingChars,
    charLimit: CHAR_LIMIT,
  };
};