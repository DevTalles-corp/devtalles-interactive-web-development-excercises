import { InputSumator } from "./components/InputSumator";

export const App = () => {
  return (
    <div className="bg-gradient">
      <InputSumator />
    </div>
  );
};