import { RandomColorGenerator } from "./components/RandomColorGenerator";

export const App = () => {
  return (
    <div className="bg-gradient">
      <RandomColorGenerator />
    </div>
  );
};