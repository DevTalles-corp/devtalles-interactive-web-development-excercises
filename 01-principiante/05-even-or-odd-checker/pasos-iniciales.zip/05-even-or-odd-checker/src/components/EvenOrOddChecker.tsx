import { useState } from "react";
import { CustomJumbotron } from "./CustomJumbotron";

// Un tipo para definir los posibles resultados.
type ResultType = "par" | "inpar" | "invalido" | null;

export const EvenOrOddChecker = () => {
  // TODO: Crea un estado `inputValue` para guardar el texto del input. Inicialízalo como string vacío.
  // TODO: Crea un estado `resultType` para guardar el tipo de resultado.
  // Utiliza el tipo `ResultType` y inicialízalo en `null`.
  
  // TODO: Implementa la lógica de la función `checkNumber`.
  const checkNumber = () => {
    // 1. Valida el `inputValue`. Si está vacío o no es un número (puedes usar `isNaN`),
    //    establece el `resultType` a "invalido" y detén la función.
    // 2. Si es válido, convierte `inputValue` a un número entero (`parseInt`).
    // 3. Usa el operador de módulo (`%`) para verificar si el número es par.
    // 4. Actualiza el estado `resultType` a "par" o "inpar" según el resultado.
  };

  // TODO: Implementa la lógica de `getResult`.
  const getResult = () => {
    // Esta función debe devolver un elemento JSX diferente según el valor de `resultType`.
    // Puedes usar un `switch` o `if/else`.

    // - Si es "par", devuelve un <p> con el texto "Es Par" y las clases CSS `result` y `even`.
    // - Si es "inpar", devuelve un <p> con el texto "Es Impar" y las clases `result` y `odd`.
    // - Si es "invalido", devuelve un <p> con el texto "Entrada no válida" y las clases `result` y `invalid`.
    // - Por defecto (si es `null`), devuelve un <p> con el texto "Esperando un número...".
    
    // Placeholder inicial:
    return <p className="result">Esperando un número...</p>;
  };

  return (
    <div className="main-container">
      <CustomJumbotron title="Verificador Par o Impar"/>
      <div className="container">
        <div className="controls">
          <input
            type="number"
            // TODO: Vincula el `value` de este input con el estado `inputValue`.
            value={""}
            // TODO: En el `onChange`, actualiza el estado `inputValue` con `e.target.value`.
            onChange={() => {}}
            placeholder="Ingresa un número"
            className="input"
          />
          {/* TODO: Llama a la función `checkNumber` cuando se haga clic en el botón. */}
          <button onClick={() => {}} className="button">
            Verificar
          </button>
        </div>
        {/* TODO: Llama a la función `getResult()` aquí para mostrar el resultado. */}
        <div className="result-container">{/* El resultado va aquí */}</div>
      </div>
    </div>
  );
};