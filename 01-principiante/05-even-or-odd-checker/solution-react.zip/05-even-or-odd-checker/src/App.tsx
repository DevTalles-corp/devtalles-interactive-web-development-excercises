import { EvenOrOddChecker } from './components/EvenOrOddChecker';

export const App = () => {
  return (
    <div className="bg-gradient">
      <EvenOrOddChecker />
    </div>
  );
};