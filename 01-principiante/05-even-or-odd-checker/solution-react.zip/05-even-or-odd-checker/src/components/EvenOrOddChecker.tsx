import { useState } from "react";
import { CustomJumbotron } from "./CustomJumbotron";

type ResultType = "par" | "inpar" | "invalido" | null;

export const EvenOrOddChecker = () => {
  const [inputValue, setInputValue] = useState<string>("");
  const [resultType, setResultType] = useState<ResultType>(null);

  const checkNumber = () => {
    if (inputValue.trim() === "" || isNaN(Number(inputValue))) {
      setResultType("invalido");
      return;
    }

    const number = parseInt(inputValue, 10);
    setResultType(number % 2 === 0 ? "par" : "inpar");
  };

  const getResult = () => {
    switch (resultType) {
      case "par":
        return <p className="result even">Es Par</p>;
      case "inpar":
        return <p className="result odd">Es Impar</p>;
      case "invalido":
        return (
          <p className={`result invalid`}>
            Entrada no válida
          </p>
        );
      default:
        return <p className="result">Esperando un número...</p>;
    }
  };

  return (
    <div className="main-container">
      <CustomJumbotron title="Verificador Par o Impar"/>
      <div className="container">
        <div className="controls">
          <input
            type="number"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Ingresa un número"
            className="input"
          />
          <button onClick={checkNumber} className="button">
            Verificar
          </button>
        </div>
        <div className="result-container">{getResult()}</div>
      </div>
    </div>
  );
};
