import { DigitalClock } from "./components/DigitalClock";

export const App = () => {
  return (
    <div className="bg-gradient">
      <DigitalClock />
    </div>
  );
};