import { CustomJumbotron } from "./custom/CustomJumbotron";
import { ProgressContainer } from "./ProgressContainer";

export const ProgressSteps = () => {

  return (
    <>
      <CustomJumbotron title="Progress Steps" />
      <ProgressContainer />
    </>
  );
};
