import { useState } from "react";

// Puedes usar este array como el número total de pasos.
const steps = [1, 2, 3, 4];

export const useSteps = () => {
  // TODO: Crea un estado llamado `currentStep` para rastrear el paso actual.
  // Debería inicializarse en 1.

  const handleNext = () => {
    // TODO: Implementa la lógica para avanzar al siguiente paso.
    // No debe permitir avanzar más allá del último paso.
  };

  const handlePrev = () => {
    // TODO: Implementa la lógica para retroceder al paso anterior.
    // No debe permitir retroceder más allá del primer paso.
  };
  
  return {
    // Properties
    steps,
    // TODO: Retorna el estado `currentStep`.
    currentStep: 1, // <- Valor temporal

    // Methods
    handleNext,
    handlePrev,

    // Compiled
    // TODO: Calcula y retorna el ancho de la barra de progreso.
    // La fórmula es: ((currentStep - 1) / (steps.length - 1)) * 100
    progressWidth: '0%', // <- Valor temporal
  }
};