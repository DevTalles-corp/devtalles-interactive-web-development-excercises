import { ProgressSteps } from "./components/ProgressSteps";

export const App = () => {
  return (
    <div className="bg-gradient">
      <ProgressSteps />
    </div>
  );
};