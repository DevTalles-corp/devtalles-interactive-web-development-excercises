import { WordReverser } from "./components/WordReverser";

export const App = () => {
  return (
    <div className="bg-gradient">
      <WordReverser />
    </div>
  );
};