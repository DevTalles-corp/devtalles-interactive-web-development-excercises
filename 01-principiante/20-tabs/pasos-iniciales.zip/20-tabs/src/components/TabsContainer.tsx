import { useState, useMemo } from 'react';
import { TabButton } from './TabButton';
import { TabPanel } from './TabPanel';
import { TabContent } from './TabContent';
import { tabsData } from '../data/data';

export const TabsContainer = () => {
  // TODO: Crea un estado `activeTabId` para guardar el ID de la pestaña activa.

  // TODO: Busca en `tabsData` el objeto completo de la pestaña que está activa.
  // Puedes usar `.find()` para comparar con `activeTabId`.
  // Opcional: Envuelve esta lógica en `useMemo` para optimizar.
  const activeTab = null; // <- Valor temporal

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div role="tablist" aria-label="Pestañas de ejemplo" className="flex border-b border-gray-600">
        {tabsData.map((tab) => (
          <TabButton
            key={tab.id}
            id={`${tab.id}-tab`}
            panelId={`${tab.id}-panel`}
            // TODO: La prop `isActive` debe ser `true` si el `id` de esta pestaña
            // es igual al `activeTabId` del estado.
            isActive={false}
            onClick={() => {}}
          >
            {tab.title}
          </TabButton>
        ))}
      </div>

      {/* TODO: Renderiza el contenido de la pestaña activa aquí. */}
      {/* 1. Asegúrate de que `activeTab` no sea nulo. */}
      {/* 2. Renderiza el componente `TabPanel` y dentro el `TabContent`*/}

    </div>
  );
};