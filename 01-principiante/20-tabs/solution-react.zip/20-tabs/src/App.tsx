import { Tabs } from "./components/Tabs";

export const App = () => {
  return (
    <div className="bg-gradient">
      <Tabs />
    </div>
  );
};