import image from '../images/image.jpg';

export const EmailSubscribeCard = () => {
  return (
    <div className="background-container">
      {/* Tarjeta */}
      <div className="card">
        {/* Contenedor flexible para la imagen y el contenido */}
        <div className="flex-container">
          {/* Imagen */}
          <img
            src={image}
            alt="Mujer haciendo ejercicio"
            className="card-image"
          />

          {/* Contenido de texto y formulario */}
          <div className="content">
            <h2 className="heading">
              Get diet and fitness tips in your inbox
            </h2>

            <p className="paragraph">
              Eat better and exercise better. Sign up for the Diet&Fitness
              newsletter.
            </p>

            {/* Contenedor del formulario */}
            <div className="form-container">
              <input
                type="email"
                placeholder="Enter your email address"
                className="email-input"
              />

              <button className="subscribe-button">
                Subscribe
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};