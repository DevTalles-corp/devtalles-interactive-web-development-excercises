import { EmailSubscribeCard } from './components/EmailSubscribeCard';

export const App = () => {
  return (
    <div className="bg-gradient">
      <EmailSubscribeCard />
    </div>
  );
};