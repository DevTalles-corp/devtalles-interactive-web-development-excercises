# 🚀 Instalación y Configuración

¡Prepárate para lanzar este proyecto en minutos! Sigue estos sencillos pasos para tener todo listo y funcionando.

---

## ✅ Prerrequisitos

Antes de comenzar, asegúrate de tener instalado el siguiente software. Vite requiere versiones actualizadas para un rendimiento óptimo.

| Software | Versión Mínima Requerida | Enlace de Descarga |
| :--- | :--- | :--- |
| **Node.js** | 18.0+ / 20.0+ | ➡️[Descargar Node.js](https://nodejs.org/es) |
| **npm** | (Incluido con Node.js) | - |
| **yarn** | (Opcional) 1.22+ | ➡️[Instalar Yarn](https://classic.yarnpkg.com/en/docs/install) |

> **Nota:** Al instalar **Node.js**, **npm** (Node Package Manager) se instala automáticamente. Puedes verificar las versiones en tu terminal con `node -v` y `npm -v`.

---

## 🛠️ Pasos de Instalación

1.  **Instala las dependencias** del proyecto. Elige tu gestor de paquetes preferido:

    ```bash
    # Usando npm
    npm install
    ```

    ```bash
    # O usando yarn
    yarn install
    ```

2.  **Inicia el servidor de desarrollo:**

    ```bash
    # Usando npm
    npm run dev
    ```

    ```bash
    # O usando yarn
    yarn dev
    ```

4.  **¡Listo! Abre tu navegador** y visita la siguiente URL para ver la aplicación en acción:
    ```
    http://localhost:5173
    ```