import { CustomJumbotron } from "./custom/CustomJumbotron"
import { PanelContainer } from "./PanelContainer"



export const ExpandingCards = () => {
  return (
    <>
      <CustomJumbotron title="Expanding Cards" />

      <PanelContainer />
    </>
  )
}