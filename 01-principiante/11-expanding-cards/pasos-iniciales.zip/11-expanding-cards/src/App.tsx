import { ExpandingCards } from "./components/ExpandingCards";

export const App = () => {
  return (
    <div className="bg-gradient">
      <ExpandingCards />
    </div>
  );
};