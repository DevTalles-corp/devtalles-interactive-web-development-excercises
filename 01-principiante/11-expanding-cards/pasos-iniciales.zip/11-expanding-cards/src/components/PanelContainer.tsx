import { useState } from 'react';
import { Panel } from './Panel';
import { panelsMockData } from '../data/images-data.mock';

export const PanelContainer = () => {
  // TODO: Crea un estado para mantener el ID del panel activo.
  // El valor inicial puede ser el ID del primer panel (ej. 0).

  const handlePanelClick = (id: number) => {
    // TODO: Implementa la lógica para actualizar el panel activo.
    // Esta función debería actualizar el estado con el 'id' del panel que fue clickeado.
  };

  return (
    <div className="flex w-full items-center justify-center p-4">
      <div className="flex w-full max-w-[80vw] gap-4">
        {panelsMockData.map((panel) => (
          // TODO: Renderiza el componente `Panel` aquí
          // y pásale todas las props que necesita para funcionar correctamente.
          <Panel imageUrl={panel.imageUrl} />
        ))}
      </div>
    </div>
  );
};