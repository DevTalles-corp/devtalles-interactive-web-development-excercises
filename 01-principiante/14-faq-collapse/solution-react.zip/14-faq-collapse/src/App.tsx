import { FaqCollapse } from "./components/FaqCollapse";

export const App = () => {
  return (
    <div className="bg-gradient">
      <FaqCollapse />
    </div>
  );
};