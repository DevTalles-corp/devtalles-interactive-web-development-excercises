import { CustomJumbotron } from "./custom/CustomJumbotron"
import { FaqContainer } from "./FaqContainer"

export const FaqCollapse = () => {
  return (
    <>
      <CustomJumbotron title="FAQ Collapse" />

      <FaqContainer />
    </>
  )
}