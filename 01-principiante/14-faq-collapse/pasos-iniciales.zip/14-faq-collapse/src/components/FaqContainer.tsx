import { useState } from "react";
import { FaqItem } from "./FaqItem";
import { faqMockData } from "../data/faq-data.mock";

export const FaqContainer = () => {
  // TODO: Crea un estado para guardar el ID del FaqItem que está abierto.
  // Puede ser un string o null (si todos están cerrados).

  const handleToggle = (id: string) => {
    // TODO: Implementa la lógica para el acordeón.
    // Si el ID clickeado es el mismo que está en el estado, ciérralo (pon el estado en null).
    // Si es diferente, actualiza el estado con el nuevo ID.
  };

  return (
    <div className="mx-auto my-8 w-full max-w-2xl rounded-lg bg-white p-6 shadow-md">
      <h2 className="mb-6 text-center text-3xl font-bold text-gray-900">
        Preguntas Frecuentes
      </h2>
      {faqMockData.map((faq) => (
        // TODO: Renderiza el componente `FaqItem` aquí.
        // Pásale las props necesarias
        <FaqItem />
      ))}
    </div>
  );
};