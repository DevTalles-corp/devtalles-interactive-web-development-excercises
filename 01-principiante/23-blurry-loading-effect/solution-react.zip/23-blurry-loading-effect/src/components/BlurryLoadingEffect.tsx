import { CustomJumbotron } from "./custom/CustomJumbotron"
import { BlurryLoadingDisplay } from "./BlurryLoadingDisplay"

export const BlurryLoadingEffect = () => {
  return (
    <div className="flex flex-col items-center gap-10 h-screen w-screen">
      <CustomJumbotron title="Blurry Loading Effect" />

      <BlurryLoadingDisplay />

    </div>
  )
}