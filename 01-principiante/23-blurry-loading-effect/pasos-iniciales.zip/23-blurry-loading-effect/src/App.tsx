import { BlurryLoadingEffect } from "./components/BlurryLoadingEffect";

export const App = () => {
  return (
    <div className="bg-gradient">
      <BlurryLoadingEffect />
    </div>
  );
};