import { ShowHidePassword } from "./components/ShowHidePassword";

export const App = () => {
  return (
    <div className="bg-gradient">
      <ShowHidePassword />
    </div>
  );
};