import { useState } from "react";
import { CustomJumbotron } from "./CustomJumbotron";

export const TemperatureConverter = () => {
  const [celsius, setCelsius] = useState<string>("");
  const [fahrenheit, setFahrenheit] = useState<string>("");

  const handleCelsiusChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (value === "") {
      setCelsius("");
      setFahrenheit("");
      return;
    }
    const numValue = parseFloat(value);
    setCelsius(value);
    setFahrenheit(((numValue * 9) / 5 + 32).toFixed(2));
  };

  const handleFahrenheitChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (value === "") {
      setCelsius("");
      setFahrenheit("");
      return;
    }
    const numValue = parseFloat(value);
    setFahrenheit(value);
    setCelsius((((numValue - 32) * 5) / 9).toFixed(2));
  };

  return (
    <div className="main-container">
      <CustomJumbotron title="Convertidor de Temperatura"/>
      <div className="container">
        <div className="input-group">
          <label htmlFor="celsius">Celsius (°C)</label>
          <input
            id="celsius"
            type="number"
            value={celsius}
            onChange={handleCelsiusChange}
            className="input"
          />
        </div>
        <div className="input-group">
          <label htmlFor="fahrenheit">Fahrenheit (°F)</label>
          <input
            id="fahrenheit"
            type="number"
            value={fahrenheit}
            onChange={handleFahrenheitChange}
            className="input"
          />
        </div>
      </div>
    </div>
  );
};
