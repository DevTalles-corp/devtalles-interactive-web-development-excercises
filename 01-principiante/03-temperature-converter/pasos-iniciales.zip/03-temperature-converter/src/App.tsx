import { TemperatureConverter } from "./components/TemperatureConverter";

export const App = () => {
  return (
    <div className="bg-gradient">
      <TemperatureConverter />
    </div>
  );
};