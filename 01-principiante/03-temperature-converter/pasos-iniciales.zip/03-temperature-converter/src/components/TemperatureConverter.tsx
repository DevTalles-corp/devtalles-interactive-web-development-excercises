import { useState } from "react";
import { CustomJumbotron } from "./CustomJumbotron";

export const TemperatureConverter = () => {
  // TODO: Crea un estado para Celsius, inicializado como un string vacío.
  // TODO: Crea un estado para Fahrenheit, inicializado como un string vacío.

  // TODO: Implementa el manejador para el cambio en el input de Celsius.
  const handleCelsiusChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;

    // 1. Actualiza el estado de Celsius con el `value`.
    // 2. Si `value` es un string vacío, resetea también el estado de Fahrenheit a un string vacío y termina la función.
    // 3. Convierte el `value` a un número.
    // 4. Calcula el valor equivalente en Fahrenheit usando la fórmula: (valorCelsius * 9/5) + 32
    // 5. Actualiza el estado de Fahrenheit con el resultado. Puedes redondearlo a 2 decimales con .toFixed(2).
  };

  // TODO: Implementa el manejador para el cambio en el input de Fahrenheit.
  const handleFahrenheitChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;

    // 1. Actualiza el estado de Fahrenheit con el `value`.
    // 2. Si `value` es un string vacío, resetea también el estado de Celsius a un string vacío.
    // 3. Convierte el `value` a un número.
    // 4. Calcula el valor equivalente en Celsius usando la fórmula: (valorFahrenheit - 32) * 5/9
    // 5. Actualiza el estado de Celsius con el resultado.
  };

  return (
    <div className="main-container">
      <CustomJumbotron title="Convertidor de Temperatura"/>
      <div className="container">
        <div className="input-group">
          <label htmlFor="celsius">Celsius (°C)</label>
          <input
            id="celsius"
            type="number"
            // TODO: Vincula el `value` de este input con el estado `celsius`.
            value={""}
            // TODO: Asigna la función `handleCelsiusChange` al evento `onChange`.
            onChange={() => {}}
            className="input"
          />
        </div>
        <div className="input-group">
          <label htmlFor="fahrenheit">Fahrenheit (°F)</label>
          <input
            id="fahrenheit"
            type="number"
            // TODO: Vincula el `value` de este input con el estado `fahrenheit`.
            value={""}
            // TODO: Asigna la función `handleFahrenheitChange` al evento `onChange`.
            onChange={() => {}}
            className="input"
          />
        </div>
      </div>
    </div>
  );
};