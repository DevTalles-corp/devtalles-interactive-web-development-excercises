import { FibonacciCounter } from './components/FibonacciCounter';

export const App = () => {
  return (
    <div className="bg-gradient">
      <FibonacciCounter />
    </div>
  );
};