import { HiddenSearchBar } from "./components/HiddenSearchBar";

export const App = () => {
  return (
    <div className="bg-gradient">
      <HiddenSearchBar />
    </div>
  );
};