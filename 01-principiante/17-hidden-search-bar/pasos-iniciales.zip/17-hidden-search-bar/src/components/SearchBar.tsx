import { useEffect, useRef, useState } from "react";
import { cn } from "../lib/utils";
import { SearchIcon } from "./SearchIcon";

export const SearchBar = () => {
  // TODO: Crea un estado booleano `isActive` para controlar si la barra está expandida.

  // TODO: Crea una referencia `inputRef` para poder acceder al elemento <input>.

  // TODO: Implementa un `useEffect`. Cuando `isActive` se vuelva `true`,
  // el <input> referenciado debe recibir el foco (focus).

  const handleToggle = () => {
    // TODO: Implementa la lógica para alternar el estado `isActive`.
  };

  const containerClasses = cn(
    `flex items-center justify-center
    bg-slate-800 rounded-full
    transition-all duration-500 ease-in-out text-white`,
    // TODO: Añade clases condicionales.
    // Si `isActive` es true, añade 'w-72 shadow-lg'.
    // Si es false, añade 'w-12'.
  );

  const inputClasses = cn(
    `w-full bg-transparent border-none 
    text-white placeholder-gray-400 focus:outline-none
    transition-all duration-500 ease-in-out`,
    // TODO: Añade clases condicionales.
    // Si `isActive` es true, añade 'pl-4 pr-2 opacity-100'.
    // Si es false, añade 'w-0 opacity-0'.
  );

  return (
    <div className={containerClasses}>
      <input
        // TODO: Asigna la referencia `inputRef` a este elemento.
        type="text"
        className={inputClasses}
        placeholder="Buscar..."
        // TODO: El input debe estar deshabilitado (`disabled`) cuando no esté activo.
        disabled={false}
      />
      <button
        onClick={() => {}}
        className="flex-shrink p-3 text-white hover:text-cyan-400 focus:outline-none"
        aria-label="Toggle search bar"
      >
        <SearchIcon />
      </button>
    </div>
  );
};