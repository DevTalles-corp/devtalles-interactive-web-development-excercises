import { MobileNavMenu } from "./components/MobileNavMenu";

export const App = () => {
  return (
    <div className="bg-gradient">
      <MobileNavMenu />
    </div>
  );
};