import { useState, useEffect } from 'react';
import { HamburgerButton } from './HamburgerButton';
import { NavPanel } from './NavPanel';
import { Overlay } from './Overlay';
import { CustomJumbotron } from './custom/CustomJumbotron';

export const MobileNavMenu = () => {
  
  // TODO: Crea un estado booleano `isOpen` para controlar si el menú está abierto o cerrado.
  // Puedes inicializarlo en `false` para indicar que está cerrado.

  const toggleMenu = () => {
    // TODO: Implementa la lógica para invertir el valor actual del estado `isOpen`.
  };
  
  // TODO (Opcional): Utiliza un useEffect para añadir o quitar la clase 'overflow-hidden' del <body>
  // cuando el estado `isOpen` cambia. Esto previene el scroll del contenido de fondo cuando el
  // menú está abierto. No olvides la función de limpieza.

  return (
    <div className="bg-slate-800 min-h-screen text-white">
      <header className="bg-slate-800 shadow-md p-4 flex justify-between items-center">
        <CustomJumbotron title='Mobile NavMenu'/>
        
        {/* TODO: Pasa las props necesarias al componente HamburgerButton.*/}
        <HamburgerButton />
      </header>

      <main className="p-8 text-white">
        <h2 className="text-2xl font-semibold mb-4">Contenido Principal</h2>
        <p>
          Usa el botón de hamburguesa en la esquina superior derecha para abrir el menú de navegación.
        </p>
      </main>

      {/* TODO: Pasa la prop `isOpen` al componente NavPanel para controlar su visibilidad. */}
      <NavPanel />
      
      {/* TODO: Pasa las props necesarias al componente Overlay.*/}
      <Overlay />
    </div>
  );
};