import { PricingCard } from './PricingCard';
import { pricingPlans } from '../data/pricing-plans-data.mock';
import styles from './PricingCard.module.css';

export const PricingCards = () => {
  return (
    // Global Container
    <div className={styles.globalContainer}>
      {/* Inner Container */}
      <div className={styles.innerContainer}>
        {pricingPlans.map((plan, index) => (
          <PricingCard
            key={index}
            plan={plan.plan}
            storage={plan.storage}
            price={plan.price}
            features={plan.features}
            isHighlighted={plan.isHighlighted}
          />
        ))}
      </div>
    </div>
  );
}