
export const pricingPlans = [
  {
    plan: 'Basic',
    storage: '100GB',
    price: '$1.99/Month',
    features: ['100 GB of storage', 'Option to add members', 'Extra member benefits'],
    isHighlighted: false,
  },
  {
    plan: 'Standard',
    storage: '200GB',
    price: '$3.99/Month',
    features: ['200 GB of storage', 'Option to add members', 'Extra member benefits'],
    isHighlighted: true,
  },
  {
    plan: 'Premium',
    storage: '2 TB',
    price: '$8.99/Month',
    features: ['2 TB of storage', 'Option to add members', 'Extra member benefits'],
    isHighlighted: false,
  },
];