import { PricingCard } from './PricingCard';
import { pricingPlans } from '../data/pricing-plans-data.mock';

export const PricingCards = () => {
  return (
    // Global Container
    <div className="flex items-center justify-center min-h-screen bg-slate-800">
      {/* Inner Container */}
      <div className="flex flex-col my-6 space-y-6 md:space-y-0 md:space-x-6 md:flex-row md:my-0">
        {pricingPlans.map((plan, index) => (
          <PricingCard
            key={index}
            plan={plan.plan}
            storage={plan.storage}
            price={plan.price}
            features={plan.features}
            isHighlighted={plan.isHighlighted}
          />
        ))}
      </div>
    </div>
  );
}