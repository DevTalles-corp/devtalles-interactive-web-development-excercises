import { GalleryFilter } from "./components/GalleryFilter";

export const App = () => {
  return (
    <div className="bg-gradient">
      <GalleryFilter />
    </div>
  );
};