import { ProductModal } from "./components/ProductModal";

export const App = () => {
  return (
    <div className="bg-gradient">
      <ProductModal />
    </div>
  );
};