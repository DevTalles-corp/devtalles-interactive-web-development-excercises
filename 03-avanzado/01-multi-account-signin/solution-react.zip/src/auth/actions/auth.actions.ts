import { signInWithPopup, signOut, type UserCredential } from "firebase/auth";
import { auth, googleProvider, githubProvider } from "../../firebase/firebase";

export const loginWithGoogleAction = async (): Promise<UserCredential> => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result;
  } catch (error) {
    console.error("Error en el login con Google:", error);
    throw error;
  }
};

export const loginWithGitHubAction = async (): Promise<UserCredential> => {
  try {
    const result = await signInWithPopup(auth, githubProvider);
    return result;
  } catch (error) {
    console.error("Error en el login con GitHub:", error);
    throw error;
  }
};

export const logoutAction = async (): Promise<void> => {
  try {
    await signOut(auth);
  } catch (error) {
    console.error("Error al cerrar sesión:", error);
    throw error;
  }
};