import { useState, useEffect, type ReactNode } from "react";
import { onAuthStateChanged, type User } from "firebase/auth";
import { auth } from "../../firebase/firebase";
import { AuthContext } from "./AuthContext";
import {
  loginWithGoogleAction,
  loginWithGitHubAction,
  logoutAction,
} from "../actions/auth.actions";

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);


  return (
    <AuthContext.Provider
      value={{
        actions: {
          loginWithGitHubAction,
          loginWithGoogleAction,
          logoutAction,
        },
        loading,
        user,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
