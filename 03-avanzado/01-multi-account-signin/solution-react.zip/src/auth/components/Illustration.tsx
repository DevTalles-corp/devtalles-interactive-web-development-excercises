interface Props {
  src: string;
  alt: string;
}

export const Illustration = ({ alt, src }: Props) => {
  return (
    // Contenedor para aplicar el gradiente y ocultar el desborde
    <div className="relative h-full w-full hidden md:block">
        {/* Gradiente que se superpone a la imagen para una transición suave */}
        <div className="absolute inset-0 bg-gradient-to-r from-slate-800/50 via-slate-800/10 to-transparent"></div>
        <img
            src={src}
            alt={alt}
            className="object-fill w-full h-full"
        />
    </div>
  );
};