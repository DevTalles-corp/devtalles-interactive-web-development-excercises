import { use } from "react";
import { AuthContext } from "../context/AuthContext";
import { LoginCard } from "../components/LoginCard";

export const LoginPage = () => {
  const { actions } = use(AuthContext);

  const handleLogin = async (provider: "google" | "github") => {
    try {
      if (provider === "google") {
        await actions.loginWithGoogleAction();
      } else {
        await actions.loginWithGitHubAction();
      }
    } catch (error) {
      console.warn(error);
      // El error ya se loguea en el archivo de acciones
      // Aquí podrías mostrar una notificación al usuario si quisieras
    }
  };

  return (
    <div className="bg-gradient flex items-center justify-center min-h-screen bg-rose-50">
      <LoginCard onLogin={handleLogin} />
    </div>
  );
};
