import { use } from 'react';
import { Navigate, Outlet } from 'react-router';
import { AuthContext } from '../../auth/context/AuthContext';

export const PublicRoute = () => {
  const { user, loading } = use(AuthContext);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p>Verificando sesión...</p>
      </div>
    );
  }

  if (user) {
    return <Navigate to="/profile" replace />;
  }
  
  return <Outlet />;
};