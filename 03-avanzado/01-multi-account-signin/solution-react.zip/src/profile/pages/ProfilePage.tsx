import { use } from 'react';
import { AuthContext } from '../../auth/context/AuthContext';

export const ProfilePage= () => {
  const { user, loading, actions } = use(AuthContext);

  const handleLogout = async () => {
    try {
      await actions.logoutAction();
    } catch (error) {
      // El error ya se maneja en la acción
      console.log(error)
    }
  };

  if (loading || !user) {
    return (
        <div className="flex items-center justify-center min-h-screen">
            <p>Cargando...</p>
        </div>
    );
  }

  const { displayName, email, photoURL, providerData } = user;
  const providerId = providerData[0].providerId;
  const providerName = providerId === 'google.com' ? ' Google' : ' GitHub';

  return (
    <div className="bg-gradient flex items-center justify-center min-h-screen">
      <div className="w-full max-w-sm mx-auto bg-slate-800 bg-opacity-70 rounded-lg shadow-xl overflow-hidden">
        <div className="p-6">
          <div className="text-center">
            <img 
                className="w-24 h-24 rounded-full mx-auto border-4 border-slate-600"
                src={photoURL || ''}
                alt="Foto de perfil"
                referrerPolicy="no-referrer"
            />
            <h2 className="text-2xl font-bold text-slate-300 mt-4">{displayName}</h2>
            <p className="text-slate-400">{email}</p>
            <p className="mt-2 text-sm text-slate-500">
                Iniciaste sesión con: 
                <span className="font-semibold text-slate-300">
                    { providerName }
                </span>
            </p>
          </div>
          <div className="mt-6">
            <button
              onClick={handleLogout}
              className="w-full py-2 px-4 bg-indigo-600 text-slate-300 hover:bg-indigo-700 rounded-md transition-colors font-semibold"
            >
              Cerrar Sesión
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}