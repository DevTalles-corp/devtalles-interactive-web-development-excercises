## 🚀 Instalación y Configuración

### Prerrequisitos

- **Node.js** 18.0+
- **npm** 9.0+ o **yarn** 1.22+

### Pasos de Instalación

1.  **Configura las variables de entorno**

    Duplica o renombra el archivo `.env.template` a `.env`. 
    Una vez que tengas tu archivo `.env`, ábrelo y añade los valores correspondientes para tus variables de entorno.

2.  **Instala las dependencias**
    ```bash
    npm install
    # o
    yarn install
    ```

3.  **Inicia el servidor de desarrollo**
    ```bash
    npm run dev
    # o
    yarn dev
    ```

4.  **Abre en el navegador web**
    ```
    http://localhost:5173
    ```