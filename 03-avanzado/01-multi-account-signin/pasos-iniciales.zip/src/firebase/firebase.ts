import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, GithubAuthProvider } from "firebase/auth";

// TODO: Rellena este objeto con la configuración de tu propio proyecto de Firebase.
// Puedes encontrar estas credenciales en la consola de Firebase, en la
// configuración de tu proyecto, en la sección "Tus apps".
//
// 📘 Documentación para obtener la configuración:
// https://firebase.google.com/docs/web/learn-more#config-object
const firebaseConfig = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: "",
};


// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.addScope('email'); 
export const githubProvider = new GithubAuthProvider();