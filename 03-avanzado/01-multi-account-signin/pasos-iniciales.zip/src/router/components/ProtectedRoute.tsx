import { use } from 'react';
import { Navigate, Outlet } from 'react-router';
import { AuthContext } from '../../auth/context/AuthContext';

export const ProtectedRoute = () => {
  const { user, loading } = use(AuthContext);

  if (loading) {
    return <p>Verificando sesión...</p>;
  }

  // TODO: Implementa la lógica de protección.
  // Si NO hay un `user` autenticado, redirige al usuario a la página
  // de login ('/login'). Para ello, usa el componente <Navigate />.
  // Si SÍ hay un `user`, permite el acceso renderizando <Outlet />.
  //
  // 📘 Documentación de React Router sobre rutas anidadas y layouts (te servirá para hacer las rutas protegidas):
  // https://reactrouter.com/start/data/routing#layout-routes
  
  return <Outlet />; // Placeholder
};