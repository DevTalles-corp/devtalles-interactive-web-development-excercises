import { use } from 'react';
import { Navigate, Outlet } from 'react-router';
import { AuthContext } from '../../auth/context/AuthContext';

export const PublicRoute = () => {
  const { user, loading } = use(AuthContext);

  if (loading) {
    return <p>Verificando sesión...</p>;
  }

  // TODO: Implementa la lógica de la ruta pública.
  // Si SÍ hay un `user` autenticado, redirígelo a su página de perfil ('/profile').
  // Si NO hay `user`, permite que vea la página de login renderizando <Outlet />.
  
  return <Outlet />; // Placeholder
};