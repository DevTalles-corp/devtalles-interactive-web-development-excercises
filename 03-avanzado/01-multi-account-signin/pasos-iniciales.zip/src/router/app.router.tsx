import { createBrowserRouter, Navigate } from "react-router";
import { PublicRoute } from "./components/PublicRoute";
import { ProtectedRoute } from "./components/ProtectedRoute";
import { ProfilePage } from "../profile/pages/ProfilePage";
import { LoginPage } from "../auth/pages/LoginPage";


export const appRouter = createBrowserRouter([
  {
    path: '/',
    element: <Navigate to='/login' />
  },
  {
    // Rutas públicas (solo para usuarios no logueados)
    element: <PublicRoute />,
    children: [
      {
        path: '/login',
        element: <LoginPage />,
      },
      // Aquí podrías añadir /register, /forgot-password, etc.
    ],
  },
  {
    // Rutas privadas (solo para usuarios logueados)
    element: <ProtectedRoute />,
    children: [
      {
        path: '/profile',
        element: <ProfilePage />,
      },
      // Aquí podrías añadir /dashboard, /settings, etc.
    ],
  },
  {
    path: '*',
    element: <Navigate to='/' />
  }
]);