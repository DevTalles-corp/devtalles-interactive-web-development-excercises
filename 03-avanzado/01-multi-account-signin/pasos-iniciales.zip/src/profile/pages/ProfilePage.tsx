import { use } from 'react';
import { AuthContext } from '../../auth/context/AuthContext';

export const ProfilePage= () => {
  const { } = use(AuthContext);

  const handleLogout = async () => {
    try {
      // TODO: Llama a la acción para cerrar sesión desde el contexto.
    } catch (error) {
      console.log(error)
    }
  };

  if (loading || !user) {
    return (
        <div className="flex items-center justify-center min-h-screen">
            <p>Cargando...</p>
        </div>
    );
  }

  // TODO: Extrae la información del objeto `user`.
  // El `providerId` (ej: 'google.com') se encuentra en `providerData[0]`.
  //
  // 📘 Documentación sobre el objeto User:
  // https://firebase.google.com/docs/reference/js/auth.user
  // https://firebase.google.com/docs/reference/js/auth.userinfo.md#userinfo_interface
  
  const displayName = "Nombre del Usuario"; // Placeholder
  const email = "email@ejemplo.com"; // Placeholder
  const photoURL = ""; // Placeholder
  const providerId = "google.com"; // Placeholder
  const providerName = providerId === 'google.com' ? ' Google' : ' GitHub';

  return (
    <div className="bg-gradient flex items-center justify-center min-h-screen">
      <div className="w-full max-w-sm mx-auto bg-slate-800 bg-opacity-70 rounded-lg shadow-xl overflow-hidden">
        <div className="p-6">
          <div className="text-center">
            <img 
                className="w-24 h-24 rounded-full mx-auto border-4 border-slate-600"
                src={photoURL || ''}
                alt="Foto de perfil"
                referrerPolicy="no-referrer"
            />
            <h2 className="text-2xl font-bold text-slate-300 mt-4">{displayName}</h2>
            <p className="text-slate-400">{email}</p>
            <p className="mt-2 text-sm text-slate-500">
                Iniciaste sesión con: 
                <span className="font-semibold text-slate-300">
                    {/* Provider */}
                    Google
                </span>
            </p>
          </div>
          <div className="mt-6">
            <button
              onClick={() => {}}
              className="w-full py-2 px-4 bg-indigo-600 text-slate-300 hover:bg-indigo-700 rounded-md transition-colors font-semibold"
            >
              Cerrar Sesión
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}