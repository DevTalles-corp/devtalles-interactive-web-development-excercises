import { Illustration } from "./Illustration";
import { SocialLoginButtons } from "./SocialLoginButtons";

interface Props {
  onLogin: (provider: "google" | "github") => Promise<void>;
}

export const LoginCard = ({ onLogin }: Props) => {
  return (
    <div className="relative flex flex-col w-full max-w-4xl overflow-hidden bg-slate-800/50 backdrop-blur-sm border border-slate-700 shadow-2xl rounded-2xl md:flex-row">
      {/* Sección Izquierda: Contenido y Acciones */}
      <div className="flex flex-col justify-center p-8 md:p-14 md:w-1/2">
        <span className="mb-3 text-4xl font-bold text-white">¡Bienvenido!</span>
        <span className="font-light text-slate-400 mb-8">
          Selecciona un proveedor para continuar.
        </span>

        <SocialLoginButtons onLogin={() => {}} />
      </div>

      {/* Sección Derecha: Ilustración */}
      <div className="relative md:w-1/2">
        <Illustration
          src="/devi-banner.jpg"
          alt="Ilustración de astronauta desarrollador"
        />
      </div>
    </div>
  );
};
