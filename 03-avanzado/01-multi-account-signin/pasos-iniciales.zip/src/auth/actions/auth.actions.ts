import { signInWithPopup, signOut, type UserCredential } from "firebase/auth";
import { auth, googleProvider, githubProvider } from "../../firebase/firebase";

export const loginWithGoogleAction = async (): Promise<UserCredential> => {
  try {
    // TODO: Implementa el inicio de sesión con el popup de Google.
    // Llama a la función `signInWithPopup` pasándole la instancia `auth` y el `googleProvider`.
    // La función devuelve una promesa que resuelve con las credenciales del usuario.
    //
    // 📘 Documentación de `signInWithPopup`:
    // https://firebase.google.com/docs/auth/web/google-signin#handle_the_sign-in_flow_with_the_firebase_sdk
    
  } catch (error) {
    console.error("Error en el login con Google:", error);
    throw error;
  }
};

export const loginWithGitHubAction = async (): Promise<UserCredential> => {
  try {
    // TODO: Implementa el inicio de sesión con el popup de GitHub.
    // Es idéntico al de Google, pero debes usar el `githubProvider`.

  } catch (error) {
    console.error("Error en el login con GitHub:", error);
    throw error;
  }
};

export const logoutAction = async (): Promise<void> => {
  try {
    // TODO: Implementa el cierre de sesión.
    // Llama a la función `signOut` pasándole la instancia `auth`.
    //
    // 📘 Documentación de `signOut`:
    // https://firebase.google.com/docs/auth/web/password-auth#sign_out
    
  } catch (error) {
    console.error("Error al cerrar sesión:", error);
    throw error;
  }
};