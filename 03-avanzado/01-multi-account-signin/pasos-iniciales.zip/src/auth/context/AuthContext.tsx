import { createContext } from "react";
import type { User, UserCredential } from "firebase/auth";

interface AuthContextType {
  user: User | null;
  loading: boolean;
  actions: {
    loginWithGoogleAction: () => Promise<UserCredential>;
    loginWithGitHubAction: () => Promise<UserCredential>;
    logoutAction: () => Promise<void>;
  };
}

export const AuthContext = createContext({} as AuthContextType);