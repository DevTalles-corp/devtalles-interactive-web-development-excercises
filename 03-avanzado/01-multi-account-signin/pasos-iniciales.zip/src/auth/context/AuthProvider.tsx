import { useState, useEffect, type ReactNode } from "react";
import { onAuthStateChanged, type User } from "firebase/auth";
import { auth } from "../../firebase/firebase";
import { AuthContext } from "./AuthContext";
import {
  loginWithGoogleAction,
  loginWithGitHubAction,
  logoutAction,
} from "../actions/auth.actions";

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // onAuthStateChanged es un observador que se dispara cada vez que el estado
    // de autenticación del usuario cambia (login, logout).

    /*
      const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
        TODO: Actualiza el estado basado en `currentUser`.
        1. Asigna el `currentUser` al estado `user`.
           (Si el usuario cierra sesión, `currentUser` será `null`).
        2. Establece el estado `loading` en `false` para indicar que la
           verificación inicial ha terminado.
                📘 Documentación de `onAuthStateChanged`:
        https://firebase.google.com/docs/auth/web/manage-users#get_the_currently_signed-in_user
        
      });
  
      La función de limpieza se ejecuta cuando el componente se desmonta.
      Es importante desuscribirse del observador para evitar fugas de memoria.
      return () => unsubscribe();  
    */
 }, []);


  return (
    <AuthContext.Provider
      value={{
        actions: {
          loginWithGitHubAction,
          loginWithGoogleAction,
          logoutAction,
        },
        loading,
        user,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};