import { use } from "react";
import { AuthContext } from "../context/AuthContext";
import { LoginCard } from "../components/LoginCard";

export const LoginPage = () => {
  const { actions } = use(AuthContext);

  const handleLogin = async (provider: "google" | "github") => {
    try {
      // TODO: Implementa la lógica para llamar a la acción de login correcta.
      // 1. Comprueba si el `provider` es "google".
      // 2. Si es "google", llama a la acción correspondiente.
      // 3. Si no, es "github", así que llama a la acción correspondiente.

    } catch (error) {
      console.warn(error);
      // El error ya se loguea en el archivo de acciones.
      // Aquí podrías mostrar una notificación al usuario si quisieras.
    }
  };

  return (
    <div className="bg-gradient flex items-center justify-center min-h-screen">
      <LoginCard onLogin={handleLogin} />
    </div>
  );
};