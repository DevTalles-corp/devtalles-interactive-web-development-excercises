import { RouterProvider } from "react-router"
import { appRouter } from "./router/app.router"
import { AuthProvider } from "./auth/context/AuthProvider"

export const App = () => {
  
  return (
    <AuthProvider>
      <RouterProvider router={appRouter} />
    </AuthProvider>
  )
}
